from django import forms
from django.contrib.auth.models import User

from .models import Gallery, Picture


class GalleryForm(forms.ModelForm):

    class Meta:
        model = Gallery
        fields = ['artist', 'gallery_title', 'category', 'gallery_logo']


class PictureForm(forms.ModelForm):

    class Meta:
        model = Picture
        fields = ['image_title', 'image_file']


class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']