from django.conf.urls import url


from . import views

app_name = 'photos'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^register/$', views.register, name='register'),
    url(r'^login_user/$', views.login_user, name='login_user'),
    url(r'^logout_user/$', views.logout_user, name='logout_user'),
    url(r'^(?P<gallery_id>[0-9]+)/$', views.detail, name='detail'),
    url(r'^(?P<picture_id>[0-9]+)/favorite/$', views.favorite, name='favorite'),
    url(r'^pictures/(?P<filter_by>[a-zA_Z]+)/$', views.pictures, name='pictures'),
    url(r'^create_gallery/$', views.create_gallery, name='create_gallery'),
    url(r'^(?P<gallery_id>[0-9]+)/create_picture/$', views.create_picture, name='create_picture'),
    url(r'^(?P<gallery_id>[0-9]+)/delete_picture/(?P<picture_id>[0-9]+)/$', views.delete_picture, name='delete_picture'),
    url(r'^(?P<gallery_id>[0-9]+)/favorite_gallery/$', views.favorite_gallery, name='favorite_gallery'),
    url(r'^(?P<gallery_id>[0-9]+)/delete_gallery/$', views.delete_gallery, name='delete_gallery'),
]
