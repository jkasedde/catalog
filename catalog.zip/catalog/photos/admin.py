from django.contrib import admin
from .models import Gallery, Picture

admin.site.register(Gallery)
admin.site.register(Picture)
