from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from .forms import GalleryForm, PictureForm, UserForm
from .models import Gallery, Picture

IMAGE_FILE_TYPES = ['png', 'jpg', 'jpeg']


def create_gallery(request):
    if not request.user.is_authenticated():
        return render(request, 'photos/login.html')
    else:
        form = GalleryForm(request.POST or None, request.FILES or None)
        if form.is_valid():
            gallery = form.save(commit=False)
            gallery.user = request.user
            gallery.gallery_logo = request.FILES['gallery_logo']
            file_type = gallery.gallery_logo.url.split('.')[-1]
            file_type = file_type.lower()
            if file_type not in IMAGE_FILE_TYPES:
                context = {
                    'gallery': gallery,
                    'form': form,
                    'error_message': 'Image file must be PNG, JPG, or JPEG',
                }
                return render(request, 'photos/create_gallery.html', context)
            gallery.save()
            return render(request, 'photos/detail.html', {'gallery': gallery})
        context = {
            "form": form,
        }
        return render(request, 'photos/create_gallery.html', context)


def create_picture(request, gallery_id):
    form = PictureForm(request.POST or None, request.FILES or None)
    gallery = get_object_or_404(Gallery, pk=gallery_id)
    if form.is_valid():
        gallerys_pictures = gallery.picture_set.all()
        for s in gallerys_pictures:
            if s.picture_title == form.cleaned_data.get("picture_title"):
                context = {
                    'gallery': gallery,
                    'form': form,
                    'error_message': 'You already added that picture',
                }
                return render(request, 'photos/create_picture.html', context)
        picture = form.save(commit=False)
        picture.gallery = gallery
        picture.image_file = request.FILES['image_file']
        file_type = picture.image_file.url.split('.')[-1]
        file_type = file_type.lower()
        if file_type not in IMAGE_FILE_TYPES:
                context = {
                    'gallery': gallery,
                    'form': form,
                    'error_message': 'Image file must be PNG, JPG, or JPEG',
                }
        return render(request, 'photos/create_picture.html', context)

        picture.save()
        return render(request, 'photos/detail.html', {'gallery': gallery})
    context = {
        'gallery': gallery,
        'form': form,
    }
    return render(request, 'photos/create_picture.html', context)


def delete_gallery(request, gallery_id):
    gallery = Gallery.objects.get(pk=gallery_id)
    gallery.delete()
    gallerys = gallery.objects.filter(user=request.user)
    return render(request, 'photos/index.html', {'Gallery': gallerys})


def delete_picture(request, gallery_id, picture_id):
    gallery = get_object_or_404(Gallery, pk=gallery_id)
    picture = Picture.objects.get(pk=picture_id)
    picture.delete()
    return render(request, 'photos/detail.html', {'gallery': gallery})


def detail(request, gallery_id):
    if not request.user.is_authenticated():
        return render(request, 'photos/login.html')
    else:
        user = request.user
        gallery = get_object_or_404(Gallery, pk=gallery_id)
        return render(request, 'photos/detail.html', {'gallery': gallery, 'user': user})


def favorite(request, picture_id):
    picture = get_object_or_404(Picture, pk=picture_id)
    try:
        if picture.is_favorite:
            picture.is_favorite = False
        else:
            picture.is_favorite = True
        picture.save()
    except (KeyError, picture.DoesNotExist):
        return JsonResponse({'success': False})
    else:
        return JsonResponse({'success': True})


def favorite_gallery(request, gallery_id):
    gallery = get_object_or_404(Gallery, pk=gallery_id)
    try:
        if gallery.is_favorite:
            gallery.is_favorite = False
        else:
            gallery.is_favorite = True
        gallery.save()
    except (KeyError, gallery.DoesNotExist):
        return JsonResponse({'success': False})
    else:
        return JsonResponse({'success': True})


def index(request):
    if not request.user.is_authenticated():
        return render(request, 'photos/login.html')
    else:
        gallerys = Gallery.objects.filter(user=request.user)
        picture_results = Picture.objects.all()
        query = request.GET.get("q")
        if query:
            gallerys = gallerys.filter(
                Q(gallery_title__icontains=query) |
                Q(artist__icontains=query)
            ).distinct()
            picture_results = picture_results.filter(
                Q(picture_title__icontains=query)
            ).distinct()
            return render(request, 'photos/index.html', {
                'Gallery': gallerys,
                'pictures': picture_results,
            })
        else:
            return render(request, 'photos/index.html', {'Gallery': gallerys})


def logout_user(request):
    logout(request)
    form = UserForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, 'photos/login.html', context)


def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                gallery = Gallery.objects.filter(user=request.user)
                return render(request, 'photos/index.html', {'gallery': gallery})
            else:
                return render(request, 'photos/login.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'photos/login.html', {'error_message': 'Invalid login'})
    return render(request, 'photos/login.html')


def register(request):
    form = UserForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        user.set_password(password)
        user.save()
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                gallery = Gallery.objects.filter(user=request.user)
                return render(request, 'photos/index.html', {'gallery': gallery})
    context = {
        "form": form,
    }
    return render(request, 'photos/register.html', context)


def pictures(request, filter_by):
    if not request.user.is_authenticated():
        return render(request, 'photos/login.html')
    else:
        try:
            picture_ids = []
            for gallery in Gallery.objects.filter(user=request.user):
                for picture in gallery.picture_set.all():
                    picture_ids.append(picture.pk)
            users_pictures = picture.objects.filter(pk__in=picture_ids)
            if filter_by == 'favorites':
                users_pictures = users_pictures.filter(is_favorite=True)
        except gallery.DoesNotExist:
            users_pictures = []
        return render(request, 'photos/pictures.html', {
            'picture_list': users_pictures,
            'filter_by': filter_by,
        })
