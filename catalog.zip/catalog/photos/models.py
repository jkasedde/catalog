from django.contrib.auth.models import Permission, User
from django.db import models


class Gallery(models.Model):
    user = models.ForeignKey(User, default=1)
    artist = models.CharField(max_length=250, default='')
    gallery_title = models.CharField(max_length=500, default='')
    category = models.CharField(max_length=100, default='')
    gallery_logo = models.FileField()
    is_favorite = models.BooleanField(default=False)

    def __str__(self):
        return self.gallery_title + ' - ' + self.artist


class Picture(models.Model):
    gallery = models.ForeignKey(Gallery, on_delete=models.CASCADE)
    image_title = models.CharField(max_length=250, default='')
    image_file = models.FileField()
    is_favorite = models.BooleanField(default=False)

    def __str__(self):
        return self.picture_title
