from django.apps import AppConfig


class PhotosConfig(AppConfig):
    name = 'photos'
